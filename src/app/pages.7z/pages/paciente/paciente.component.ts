import { Component, OnInit } from '@angular/core';
import { PacientesService } from 'src/app/_services/pacientes.service';

@Component({
  selector: 'app-paciente',
  templateUrl: './paciente.component.html',
  styleUrls: ['./paciente.component.css']
})
export class PacienteComponent implements OnInit {

  constructor(private pacienteService : PacientesService) { }

  ngOnInit(): void {
    this.pacienteService.listar();
  }

}
